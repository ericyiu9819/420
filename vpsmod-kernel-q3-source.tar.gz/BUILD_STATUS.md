# Build Status

Last local check environment:

```text
Darwin arm64
```

This machine is not a valid target for producing Debian/Ubuntu x86_64 VPS
kernel packages.

## Passed Locally

```text
PATCH_ONLY=1 ./scripts/preflight.sh
```

Result:

```text
Patch preflight OK for linux-6.12.91
```

Verified:

- official linux-6.12.91 source tarball can be unpacked
- `0001-net-ipv4-add-bbrvps-congestion-control.patch` applies cleanly
- `net/ipv4/tcp_bbrvps.c` is created
- `CONFIG_TCP_CONG_BBRVPS` exists in Kconfig
- `tcp_bbrvps.o` is registered in Makefile
- congestion-control name is `bbrvps`
- local certificate paths are cleared for official kernel.org source builds

## Not Run Locally

These require a Linux builder with GNU Make 4.0+:

```text
./scripts/preflight.sh
./scripts/build-deb.sh
```

The local macOS Make is 3.81, and Linux kernel 6.12 requires GNU Make 4.0+.

## Required Linux Builder

Recommended:

```text
Ubuntu 24.04 x86_64
4 vCPU or more
16 GB RAM or more
40 GB free disk or more
```

Run:

```bash
sudo apt update
sudo apt install -y \
  build-essential bc bison flex libssl-dev libelf-dev dwarves pahole \
  rsync curl tar xz-utils fakeroot dpkg-dev debhelper kmod cpio

./scripts/preflight.sh
JOBS=4 ./scripts/build-deb.sh
```
