# Test BBRVPS

The first `bbrvps` patch is intentionally conservative. It registers a separate
congestion-control module named `bbrvps`, but keeps behavior equivalent to the
official BBR baseline.

## Confirm Module Availability

After booting the vpsmod kernel:

```bash
uname -a
modprobe tcp_bbrvps
sysctl net.ipv4.tcp_available_congestion_control
```

Expected:

```text
... cubic reno bbr bbrvps
```

The exact order can differ.

## Test Without Making It Permanent

```bash
sudo sysctl -w net.core.default_qdisc=fq
sudo sysctl -w net.ipv4.tcp_congestion_control=bbrvps
sysctl net.ipv4.tcp_congestion_control
```

Switch back immediately if needed:

```bash
sudo sysctl -w net.ipv4.tcp_congestion_control=bbr
```

Or:

```bash
sudo sysctl -w net.ipv4.tcp_congestion_control=cubic
```

## Basic Network Smoke Test

```bash
ping -c 20 1.1.1.1
curl -4 https://ifconfig.me
curl -6 https://ifconfig.me
iperf3 -c <nearby-test-server>
iperf3 -R -c <nearby-test-server>
```

## Do Not Persist Yet

Do not write `bbrvps` into `/etc/sysctl.conf` until:

- the VPS has survived multiple reboots
- SSH remains stable under load
- rescue console access is confirmed
- official `bbr` and `cubic` fallback both work
