# Debian/Ubuntu Builder Setup

Run this on the machine that will compile the kernel:

```bash
sudo apt update
sudo apt install -y \
  build-essential \
  bc \
  bison \
  flex \
  libssl-dev \
  libelf-dev \
  dwarves \
  pahole \
  rsync \
  curl \
  tar \
  xz-utils \
  fakeroot \
  dpkg-dev \
  debhelper \
  kmod \
  cpio
```

Then build:

```bash
./scripts/preflight.sh
./scripts/build-deb.sh
```

For a smaller build machine:

```bash
JOBS=2 ./scripts/build-deb.sh
```

To pin another 6.12.y version:

```bash
KERNEL_VERSION=6.12.91 ./scripts/build-deb.sh
```

Do not run the first build on a production VPS.

On macOS or another non-Linux machine, only this limited check is meaningful:

```bash
PATCH_ONLY=1 ./scripts/preflight.sh
```
