# Install Debian Packages Safely

Only test on a VPS with rescue console access.

Copy these files to the VPS:

```text
linux-image-*-vpsmod*.deb
linux-headers-*-vpsmod*.deb
```

Install:

```bash
sudo dpkg -i linux-image-*-vpsmod*.deb linux-headers-*-vpsmod*.deb
sudo update-initramfs -c -k 6.12.91-vpsmod
sudo update-grub
```

Check the new boot entry:

```bash
grep -n "6.12.91-vpsmod" /boot/grub/grub.cfg
```

Prefer a one-time boot first:

```bash
sudo grub-reboot "Advanced options for Ubuntu>Ubuntu, with Linux 6.12.91-vpsmod"
sudo reboot
```

After boot:

```bash
uname -a
ip addr
ip route
sysctl net.ipv4.tcp_available_congestion_control
sudo sysctl -w net.core.default_qdisc=fq
sudo sysctl -w net.ipv4.tcp_congestion_control=bbr
```

To test the optional `bbrvps` module, see `docs/test-bbrvps.md`.

Do not make `bbrvps` default until it has survived repeated reboot and network tests.
