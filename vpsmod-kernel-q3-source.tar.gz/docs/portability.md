# VPS Portability Notes

No custom kernel can cover every VPS environment with one artifact.

The variables that break portability are:

- CPU architecture: x86_64, arm64, riscv64
- firmware and boot path: BIOS, UEFI, PVH, provider loader
- root disk driver: virtio, NVMe, SCSI, Xen blkfront, Hyper-V storvsc
- network driver: virtio_net, ena, gve, hv_netvsc, xen-netfront, vmxnet3
- distribution packaging: deb, rpm, pacman, raw image
- provider policy: some VPS plans do not allow custom kernels

Recommended support matrix:

```text
Tier 1: Debian/Ubuntu x86_64 KVM/virtio/NVMe
Tier 2: Debian/Ubuntu x86_64 Xen/Hyper-V/VMware
Tier 3: RHEL-family rpm builds
Tier 4: arm64 cloud builds
```

The first build should target Tier 1 only.

## Safe Test Method

1. Build on a separate machine.
2. Install on a non-critical VPS.
3. Keep provider rescue console available.
4. Boot once, do not make permanent immediately.
5. Verify disk, network, SSH, DNS, clock, and package manager.
6. Only then test congestion-control changes.

## Network Test Checklist

```bash
uname -a
lsmod | grep -E 'virtio|nvme|xen|hv_|ena|gve|vmxnet3'
sysctl net.ipv4.tcp_available_congestion_control
sysctl net.ipv4.tcp_congestion_control
sysctl net.core.default_qdisc
ip route
ping -c 20 1.1.1.1
iperf3 -c <test-server>
```
