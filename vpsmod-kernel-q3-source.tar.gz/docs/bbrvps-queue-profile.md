# BBRVPS queue profile

Patch:

- `patches/0002-net-ipv4-bbrvps-add-vps-queue-profile.patch`

This profile keeps BBRVPS small and reversible. It does not add a new qdisc.
It changes the BBRVPS congestion-control queue behavior so VPS routes with
high RTT, ACK compression, and light random loss keep useful inflight without
falling back too hard.

## Changes

- Raises steady-state cwnd gain from `2.0x` to `2.25x`.
- Raises ACK aggregation credit from `1.0x` to `1.25x`.
- Uses a stronger PROBE_BW up phase: `1.25x` to `1.375x`.
- Uses a softer drain phase: `0.75x` to `0.875x`.
- Softens loss recovery by cutting half the reported loss count from cwnd.
- Caps post-loss target cwnd near current useful inflight plus a small guard.
- Adds a drain guard so long-RTT paths do not over-drain below useful inflight.

## Intent

The profile is intentionally biased toward bad VPS routes:

- under-filled cross-border routes,
- delayed or compressed ACKs,
- light random loss,
- mild provider shaping.

It is not expected to improve already-clean, low-loss routes much. On clean
routes it should behave close to BBR with a slightly larger queue budget.

## Rollback

Remove patch `0002` and rebuild. Patch `0001` remains the safe BBRVPS baseline.

## Q2 and Q3 profiles

- `0003` is the aggressive Q2 profile. It keeps higher cwnd, ACK aggregation,
  probe, and drain gains active all the time. This is useful for stubborn bad
  routes, but can add queue on already-clean lines.
- `0004` is the adaptive Q3 profile. It normally falls back to the steadier Q1
  gains, then temporarily raises pacing/cwnd/ACK credit when BBRVPS sees loss,
  RTT growth, ACK aggregation, or under-filled inflight. This is the preferred
  default for mixed VPS routes because it is more selective than Q2.
