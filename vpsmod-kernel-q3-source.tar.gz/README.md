# vpsmod-kernel

Build kit for a VPS-oriented Linux kernel based on the official longterm kernel.

## Position

There is no single kernel image that is truly suitable for every VPS system.
The practical target is:

- x86_64 cloud VPS first
- Debian/Ubuntu `.deb` packages first
- official longterm Linux 6.12.y as the main base
- official BBR, CUBIC, and recovery paths preserved
- custom `bbrvps` work added as a separate congestion-control module

Do not overwrite official `tcp_bbr.c` in the first version.

## Current Base

Pinned first target:

```text
linux-6.12.91
LOCALVERSION="-vpsmod"
```

Kernel.org listed `6.12.91` as a longterm kernel on 2026-05-23.

## Build On Debian/Ubuntu

Use a disposable build VPS or local Linux machine, not the production VPS.

```bash
cd vpsmod-kernel
./scripts/preflight.sh
./scripts/build-deb.sh
```

On non-Linux machines you can only validate the patch layer:

```bash
PATCH_ONLY=1 ./scripts/preflight.sh
```

## Build With GitHub Actions

This repository includes:

```text
.github/workflows/build-deb.yml
```

Push the `vpsmod-kernel` directory to a GitHub repository, open Actions,
run "Build Debian kernel packages", then download the `vpsmod-kernel-deb`
artifact.

The output packages will be under:

```text
build/linux-6.12.91/..
```

## Install Safely

Install only after you have console access or rescue mode available.

```bash
sudo dpkg -i linux-image-*vpsmod*.deb linux-headers-*vpsmod*.deb
sudo update-initramfs -c -k 6.12.91-vpsmod
sudo update-grub
```

On a remote VPS, boot it once first instead of making it permanent immediately.
Exact GRUB commands differ by distribution and provider.

## Runtime Defaults

Recommended first boot settings:

```bash
sudo sysctl -w net.core.default_qdisc=fq
sudo sysctl -w net.ipv4.tcp_congestion_control=bbrvps
```

The recommended queue/congestion-control pair for this project is:

```text
bbrvps + fq
```

Keep this as a runtime setting until the kernel has booted cleanly on the
target VPS. Make it persistent only after console/rescue access is confirmed.

## BBRVPS Profiles

Patch order:

```text
0001: add independent tcp_bbrvps congestion-control module
0002: Q1 VPS queue profile
0003: Q2 aggressive profile
0004: Q3 adaptive rescue profile
```

Q3 is the preferred current profile. It normally keeps the steadier Q1 gains,
then temporarily raises pacing, cwnd, and ACK aggregation credit when it sees
loss, RTT growth, ACK aggregation, or under-filled inflight.

## Tested Build

The Q3 build was compiled and boot-tested on a Debian x86_64 VPS:

```text
6.12.91-vpsmodq2-vpsmodq3
```

Verified:

- `tcp_bbrvps.ko` exists in the image package
- `modprobe tcp_bbrvps` succeeds
- `net.core.default_qdisc=fq`
- `net.ipv4.tcp_congestion_control=bbrvps`
- basic ping and HTTPS download tests pass
- no panic/oops/call-trace messages were observed during the test

## Roadmap

```text
vpsmod-0.1: official 6.12.y + VPS/cloud config + fq + official bbr
vpsmod-0.2: add CONFIG_TCP_CONG_BBRVPS=m, not default
vpsmod-0.3: Q1/Q2/Q3 BBRVPS profiles
vpsmod-0.4: rebuild Q3 from a clean source tree with a clean release name
vpsmod-0.5: port/test against newer longterm branch
```

## Non-Goals

- one binary for every distribution
- replacing official BBR globally
- removing CUBIC fallback
- shipping an untested default congestion-control algorithm
- assuming all VPS providers support custom kernels
